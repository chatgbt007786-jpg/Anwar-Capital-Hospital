import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import { INITIAL_DOCTORS, INITIAL_DEPARTMENTS, INITIAL_LAB_TESTS } from './data';
import { Doctor, Department, LabTest, Appointment, HomeServiceRequest, LabBooking } from './types';

// Page Imports (Inline for compactness or split if preferred, will define below)
import Home from './pages/Home';
import About from './pages/About';
import Departments from './pages/Departments';
import Doctors from './pages/Doctors';
import Laboratory from './pages/Laboratory';
import HomeServices from './pages/HomeServices';
import Contact from './pages/Contact';
import AdminDashboard from './pages/AdminDashboard';

const App: React.FC = () => {
  // Global State (Simulating Database)
  const [doctors, setDoctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [labTests, setLabTests] = useState<LabTest[]>(INITIAL_LAB_TESTS);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [homeRequests, setHomeRequests] = useState<HomeServiceRequest[]>([]);
  const [labBookings, setLabBookings] = useState<LabBooking[]>([]);
  const [emergencyEnabled, setEmergencyEnabled] = useState<boolean>(true);

  // Handlers for "API" calls from frontend pages
  const bookAppointment = (details: Omit<Appointment, 'id' | 'status'>) => {
    const newAppt: Appointment = { ...details, id: Date.now().toString(), status: 'Pending' };
    setAppointments([...appointments, newAppt]);
    alert('Appointment Request Submitted Successfully! Our team will contact you shortly.');
  };

  const bookHomeService = (details: Omit<HomeServiceRequest, 'id' | 'status'>) => {
    const newReq: HomeServiceRequest = { ...details, id: Date.now().toString(), status: 'Pending' };
    setHomeRequests([...homeRequests, newReq]);
    alert('Home Service Request Submitted! We are processing your request.');
  };

  const bookLabTest = (details: Omit<LabBooking, 'id' | 'status'>) => {
    const newBooking: LabBooking = { ...details, id: Date.now().toString(), status: 'Pending' };
    setLabBookings([...labBookings, newBooking]);
    // Alert removed to show receipt preview in Laboratory component instead
  };

  return (
    <HashRouter>
      <Layout emergencyEnabled={emergencyEnabled}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/departments" element={<Departments departments={departments} />} />
          <Route path="/doctors" element={<Doctors doctors={doctors} onBook={bookAppointment} />} />
          <Route path="/laboratory" element={<Laboratory tests={labTests} onBook={bookLabTest} />} />
          <Route path="/home-services" element={<HomeServices onRequest={bookHomeService} />} />
          <Route path="/contact" element={<Contact />} />
          
          <Route 
            path="/admin/*" 
            element={
              <AdminDashboard 
                doctors={doctors} setDoctors={setDoctors}
                departments={departments} setDepartments={setDepartments}
                labTests={labTests} setLabTests={setLabTests}
                appointments={appointments} setAppointments={setAppointments}
                homeRequests={homeRequests} setHomeRequests={setHomeRequests}
                emergencyEnabled={emergencyEnabled} setEmergencyEnabled={setEmergencyEnabled}
              />
            } 
          />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;