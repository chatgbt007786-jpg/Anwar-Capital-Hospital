export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  specialization: string;
  department: string;
  opdTime: string;
}

export interface Department {
  id: string;
  name: string;
  description?: string;
  isEnabled: boolean;
}

export interface LabTest {
  id: string;
  name: string;
  rate: number;
  instructions?: string;
}

export interface Appointment {
  id: string;
  patientName: string;
  contact: string;
  doctorName: string;
  date: string;
  status: 'Pending' | 'Approved' | 'Completed';
}

export interface HomeServiceRequest {
  id: string;
  type: 'Sampling' | 'Nursing';
  patientName: string;
  contact: string;
  location: string;
  details: string;
  status: 'Pending' | 'Assigned' | 'Completed';
}

export interface LabBooking {
  id: string;
  patientName: string;
  contact: string;
  tests: { id: string; name: string; price: number; originalRate: number }[];
  totalAmount: number;
  date: string;
  status: 'Pending' | 'Confirmed' | 'Completed';
}

export const DEPARTMENTS_LIST = [
  "Vaccination Department",
  "Infertility Department",
  "Physiotherapy Department",
  "Home Medical Services (G-13 / G-14)",
  "Diet & Nutrition",
  "Diabetes Treatment",
  "Hypertension Clinic",
  "Asthma Clinic",
  "Bones & Joint Diseases",
  "Arthritis Clinic",
  "Tele-Consultation",
  "Dengue & Corona Care",
  "Gastroenterology"
];