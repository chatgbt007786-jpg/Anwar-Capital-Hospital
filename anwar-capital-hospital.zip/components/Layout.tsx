import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Clock, AlertCircle } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  emergencyEnabled: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, emergencyEnabled }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isAdmin = location.pathname.startsWith('/admin');

  if (isAdmin) {
    return <div className="min-h-screen bg-gray-100">{children}</div>;
  }

  const isActive = (path: string) => location.pathname === path ? 'text-blue-600 font-bold' : 'text-gray-600 hover:text-blue-600';

  return (
    <div className="flex flex-col min-h-screen font-sans">
      {/* Top Bar */}
      <div className="bg-blue-900 text-white py-2 text-sm">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-4 mb-2 md:mb-0">
            <span className="flex items-center"><Phone size={14} className="mr-1" /> 051-2301708</span>
            <span className="flex items-center"><Phone size={14} className="mr-1" /> 0333-5613108</span>
          </div>
          <div className="flex items-center space-x-4">
             <span className="flex items-center text-yellow-300 font-semibold">
               <Clock size={14} className="mr-1" /> Hospital Services: 24/7
             </span>
             {emergencyEnabled && (
                <span className="bg-red-600 text-white px-3 py-1 rounded-full text-xs font-bold animate-pulse flex items-center">
                  <AlertCircle size={12} className="mr-1" /> EMERGENCY 24/7
                </span>
             )}
          </div>
        </div>
      </div>

      {/* Navbar */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex flex-col">
              <span className="text-2xl font-bold text-blue-800 tracking-tight">ANWAR CAPITAL HOSPITAL</span>
              <span className="text-xs text-gray-500 hidden sm:block">YOUR HEALTH, OUR PRIORITY</span>
            </Link>

            <div className="hidden md:flex space-x-8">
              <Link to="/" className={isActive('/')}>Home</Link>
              <Link to="/about" className={isActive('/about')}>About Us</Link>
              <Link to="/departments" className={isActive('/departments')}>Departments</Link>
              <Link to="/doctors" className={isActive('/doctors')}>Doctors</Link>
              <Link to="/laboratory" className={isActive('/laboratory')}>Laboratory</Link>
              <Link to="/home-services" className={isActive('/home-services')}>Home Services</Link>
              <Link to="/contact" className={isActive('/contact')}>Contact</Link>
            </div>

            <div className="hidden md:block">
              <Link to="/doctors" className="bg-blue-600 text-white px-5 py-2 rounded-md hover:bg-blue-700 transition">
                Book Appointment
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-gray-700" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t p-4 flex flex-col space-y-4">
            <Link to="/" onClick={() => setIsMenuOpen(false)}>Home</Link>
            <Link to="/about" onClick={() => setIsMenuOpen(false)}>About Us</Link>
            <Link to="/departments" onClick={() => setIsMenuOpen(false)}>Departments</Link>
            <Link to="/doctors" onClick={() => setIsMenuOpen(false)}>Doctors</Link>
            <Link to="/laboratory" onClick={() => setIsMenuOpen(false)}>Laboratory</Link>
            <Link to="/home-services" onClick={() => setIsMenuOpen(false)}>Home Services</Link>
            <Link to="/contact" onClick={() => setIsMenuOpen(false)}>Contact</Link>
          </div>
        )}
      </nav>

      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 py-10">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Anwar Capital Hospital</h3>
            <p className="text-sm mb-4">
              Providing safe, reliable, and affordable medical services in the heart of Islamabad.
              We combine advanced technology with a compassionate team.
            </p>
            <div className="text-sm">
              <a 
                href="https://share.google/OhGQdAUtBVmioh79r" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-white block"
              >
                Street 108, Sector G-13/1, Islamabad
              </a>
              <p className="mt-2">info@ach.com.pk</p>
            </div>
          </div>
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/doctors" className="hover:text-white">Find a Doctor</Link></li>
              <li><Link to="/laboratory" className="hover:text-white">Lab Tests</Link></li>
              <li><Link to="/home-services" className="hover:text-white">Home Nursing</Link></li>
              <li><Link to="/admin" className="hover:text-white text-blue-400">Admin Login</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-white text-lg font-bold mb-4">Emergency Contact</h3>
            <p className="text-2xl font-bold text-white mb-2">051-2301708</p>
            <p className="text-sm mb-4">Available 24/7 for all emergency services.</p>
            <div className="flex space-x-4">
                {/* Social Icons Placeholder */}
                <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">F</div>
                <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">T</div>
                <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center">I</div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-4 text-center text-xs">
          © 2023 Anwar Capital Hospital. All Rights Reserved.
        </div>
      </footer>
    </div>
  );
};

export default Layout;