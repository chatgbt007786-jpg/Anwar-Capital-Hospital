import React from 'react';
import { Department } from '../types';
import { Stethoscope } from 'lucide-react';

interface Props {
  departments: Department[];
}

const Departments: React.FC<Props> = ({ departments }) => {
  const activeDepts = departments.filter(d => d.isEnabled);

  return (
    <div className="py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-12 text-gray-800">Our Departments & Services</h1>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeDepts.map(dept => (
            <div key={dept.id} className="bg-white border hover:border-blue-500 rounded-lg p-6 shadow-sm hover:shadow-md transition group">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-blue-100 rounded-full group-hover:bg-blue-600 transition-colors">
                  <Stethoscope className="w-6 h-6 text-blue-600 group-hover:text-white" />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-2">{dept.name}</h3>
              <p className="text-gray-500 text-sm">Providing specialized care and treatment.</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Departments;