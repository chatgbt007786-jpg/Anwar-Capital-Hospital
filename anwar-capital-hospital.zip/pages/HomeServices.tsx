import React, { useState } from 'react';
import { HomeServiceRequest } from '../types';
import { Home, ClipboardList } from 'lucide-react';

interface Props {
  onRequest: (req: Omit<HomeServiceRequest, 'id' | 'status'>) => void;
}

const HomeServices: React.FC<Props> = ({ onRequest }) => {
  const [activeTab, setActiveTab] = useState<'sampling' | 'nursing'>('sampling');
  const [formData, setFormData] = useState({
    patientName: '',
    contact: '',
    location: '',
    details: '',
    date: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onRequest({
      type: activeTab === 'sampling' ? 'Sampling' : 'Nursing',
      ...formData,
      // Combining date into details for simplicity in this demo, or handled separately
      details: `${formData.details} (Requested Date: ${formData.date})`
    });
    setFormData({ patientName: '', contact: '', location: '', details: '', date: '' });
  };

  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="grid grid-cols-2">
            <button 
              onClick={() => setActiveTab('sampling')}
              className={`p-6 text-center font-bold flex flex-col items-center justify-center transition ${activeTab === 'sampling' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              <ClipboardList className="w-8 h-8 mb-2" />
              <span>Home Sampling</span>
              <span className="text-xs font-normal mt-1 opacity-80">Free in G-13 / G-14</span>
            </button>
            <button 
              onClick={() => setActiveTab('nursing')}
              className={`p-6 text-center font-bold flex flex-col items-center justify-center transition ${activeTab === 'nursing' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              <Home className="w-8 h-8 mb-2" />
              <span>Home Nursing</span>
              <span className="text-xs font-normal mt-1 opacity-80">24/7 Care Available</span>
            </button>
          </div>

          <div className="p-8 md:p-12">
            <h2 className="text-2xl font-bold mb-6 text-gray-800">
              Book {activeTab === 'sampling' ? 'Home Lab Sampling' : 'Home Nursing Service'}
            </h2>
            
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2 p-4 bg-yellow-50 text-yellow-800 text-sm rounded border border-yellow-200 mb-2">
                Note: Home services are currently prioritized for sectors G-13 and G-14, Islamabad.
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name</label>
                <input 
                  required
                  type="text" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.patientName}
                  onChange={e => setFormData({...formData, patientName: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
                <input 
                  required
                  type="tel" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.contact}
                  onChange={e => setFormData({...formData, contact: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">House Address (Sector G-13/14)</label>
                <input 
                  required
                  type="text" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.location}
                  onChange={e => setFormData({...formData, location: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Date/Time</label>
                <input 
                  required
                  type="datetime-local" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.date}
                  onChange={e => setFormData({...formData, date: e.target.value})}
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {activeTab === 'sampling' ? 'Tests Required / Remarks' : 'Condition / Nursing Requirements'}
                </label>
                <textarea 
                  required
                  rows={3}
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.details}
                  onChange={e => setFormData({...formData, details: e.target.value})}
                />
              </div>

              <div className="md:col-span-2">
                <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded-md hover:bg-blue-700 transition">
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeServices;