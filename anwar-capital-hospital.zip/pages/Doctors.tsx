import React, { useState } from 'react';
import { Doctor, Appointment } from '../types';
import { User, Clock, Award } from 'lucide-react';

interface Props {
  doctors: Doctor[];
  onBook: (appt: Omit<Appointment, 'id' | 'status'>) => void;
}

const Doctors: React.FC<Props> = ({ doctors, onBook }) => {
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [formData, setFormData] = useState({ patientName: '', contact: '', date: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDoctor) {
      onBook({
        doctorName: selectedDoctor.name,
        patientName: formData.patientName,
        contact: formData.contact,
        date: formData.date
      });
      setSelectedDoctor(null);
      setFormData({ patientName: '', contact: '', date: '' });
    }
  };

  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-4 text-gray-800">Our Qualified Doctors</h1>
        <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
          Meet our team of experienced consultants and specialists dedicated to your health.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {doctors.map(doctor => (
            <div key={doctor.id} className="bg-white rounded-lg shadow-sm border overflow-hidden flex flex-col h-full">
              <div className="bg-blue-50 p-6 flex flex-col items-center">
                <div className="w-24 h-24 bg-blue-200 rounded-full flex items-center justify-center mb-4 text-blue-700">
                  <User size={48} />
                </div>
                <h3 className="text-lg font-bold text-center text-gray-900">{doctor.name}</h3>
                <span className="text-blue-600 text-sm font-medium">{doctor.department}</span>
              </div>
              <div className="p-6 flex-grow flex flex-col space-y-4">
                <div className="flex items-start space-x-3">
                  <Award className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Qualification</p>
                    <p className="text-sm font-medium text-gray-800">{doctor.qualification}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Award className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">Specialization</p>
                    <p className="text-sm font-medium text-gray-800">{doctor.specialization}</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-gray-400 mt-1" />
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide">OPD Timing</p>
                    <p className="text-sm font-medium text-gray-800">{doctor.opdTime}</p>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t bg-gray-50">
                <button 
                  onClick={() => setSelectedDoctor(doctor)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 rounded-md transition"
                >
                  Book Appointment
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Booking Modal */}
      {selectedDoctor && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4">Book Appointment</h2>
            <p className="text-sm text-gray-600 mb-6">Booking for <span className="font-bold text-blue-600">{selectedDoctor.name}</span></p>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Patient Name</label>
                <input 
                  required
                  type="text" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.patientName}
                  onChange={e => setFormData({...formData, patientName: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Contact Number</label>
                <input 
                  required
                  type="tel" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.contact}
                  onChange={e => setFormData({...formData, contact: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preferred Date</label>
                <input 
                  required
                  type="date" 
                  className="w-full border rounded-md p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={formData.date}
                  onChange={e => setFormData({...formData, date: e.target.value})}
                />
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button 
                  type="button" 
                  onClick={() => setSelectedDoctor(null)}
                  className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Doctors;