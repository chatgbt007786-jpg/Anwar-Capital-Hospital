import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowRight, Activity, Users, Clock, ShieldCheck, 
  Syringe, HeartPulse, Stethoscope, Baby, Smartphone, Home as HomeIcon, 
  Phone, MapPin, Mail, Facebook, Star
} from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div>
      {/* Hero Section / Banner Recreation */}
      <section className="bg-gray-50 pt-8 pb-12">
        <div className="container mx-auto px-4">
          
          {/* Main Banner Card */}
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col lg:flex-row border border-gray-100 max-w-6xl mx-auto">
            
            {/* Left Column: Services List */}
            <div className="lg:w-5/12 bg-gradient-to-br from-blue-50 to-white p-6 sm:p-8 flex flex-col justify-center border-r border-blue-100">
              <div className="space-y-4">
                <ServiceRow icon={Syringe} title="Vaccination Center" subtitle="(Govt. Approved)" />
                <ServiceRow icon={HeartPulse} title="Hypertension & Diabetes Center" />
                <ServiceRow icon={Stethoscope} title="Gastroenterology & Liver Center" />
                <ServiceRow icon={Activity} title="Physiotherapy Center" />
                <ServiceRow icon={Baby} title="Infertility Center" />
                <ServiceRow icon={Smartphone} title="Teleconsultation" />
                <ServiceRow icon={HomeIcon} title="Home Services" subtitle="(G-13, G-14)" />
              </div>
            </div>

            {/* Right Column: Branding & Info */}
            <div className="lg:w-7/12 relative flex flex-col">
              
              {/* Branding Content */}
              <div className="flex-grow p-8 flex flex-col items-center justify-center text-center relative overflow-hidden">
                
                {/* 24/7 Badge */}
                <div className="absolute top-4 right-4 sm:top-6 sm:right-6 animate-pulse">
                  <div className="bg-white border-4 border-red-600 rounded-full w-20 h-20 sm:w-24 sm:h-24 flex flex-col items-center justify-center shadow-lg transform rotate-12">
                    <span className="text-2xl sm:text-3xl font-black text-red-600 leading-none">24/7</span>
                    <span className="text-[10px] sm:text-xs font-bold text-red-800 uppercase text-center leading-tight mt-1">Emergency<br/>Services</span>
                  </div>
                </div>

                {/* Logo & Name */}
                <div className="flex flex-col items-center mb-6">
                  <div className="w-20 h-20 bg-blue-900 rounded-full flex items-center justify-center shadow-md mb-4">
                     <span className="text-white text-4xl font-black">+</span>
                  </div>
                  <h1 className="text-5xl sm:text-6xl font-serif font-bold text-blue-900 leading-none mb-2">ACH</h1>
                  <h2 className="text-2xl sm:text-4xl text-gray-800 font-bold">Anwar Capital Hospital</h2>
                </div>

                {/* Tagline Strip */}
                <div className="w-full bg-blue-900 text-white py-4 transform -skew-x-6 shadow-xl mb-4">
                  <h3 className="text-xl sm:text-3xl font-bold transform skew-x-6 tracking-wider">
                    THE CARE <span className="text-blue-300">YOU DESERVE</span>
                  </h3>
                </div>
              </div>

              {/* Bottom Info Bar */}
              <div className="bg-gray-800 text-white">
                <div className="flex flex-col sm:flex-row">
                  {/* Address/Email */}
                  <div className="flex-1 p-4 text-xs sm:text-sm flex flex-col justify-center items-center sm:items-start space-y-2 sm:pl-8">
                    <div className="flex items-center">
                      <Mail size={14} className="mr-2 text-blue-400" /> 
                      <span>info@ach.com.pk</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin size={14} className="mr-2 text-blue-400" /> 
                      <a 
                        href="https://share.google/OhGQdAUtBVmioh79r" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="hover:text-blue-200 transition underline decoration-dotted underline-offset-4"
                      >
                        Street 108, Main Market G-13/1, Islamabad
                      </a>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center">
                        <Facebook size={14} className="mr-2 text-blue-400" /> 
                        <span>ACH Anwar Capital hospital</span>
                      </div>
                      <a 
                        href="https://share.google/OhGQdAUtBVmioh79r"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-yellow-400 hover:text-yellow-300 font-bold ml-2"
                      >
                        <Star size={14} className="mr-1 fill-current" />
                        Rate Us
                      </a>
                    </div>
                  </div>

                  {/* Phone Numbers (Red Background) */}
                  <div className="bg-red-600 p-4 flex flex-col justify-center items-center sm:items-end sm:pr-8 min-w-[250px]">
                     <div className="flex items-center font-bold text-lg">
                       <Phone size={18} className="mr-2" /> 051-2306708
                     </div>
                     <div className="flex items-center font-bold text-lg">
                       <Phone size={18} className="mr-2" /> 0333-5613108
                     </div>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row justify-center gap-4 mt-10">
            <Link to="/doctors" className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-full font-bold text-xl shadow-lg transition transform hover:-translate-y-1 flex items-center justify-center">
              Book Appointment <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link to="/home-services" className="bg-white border-2 border-blue-600 text-blue-600 hover:bg-blue-50 px-10 py-4 rounded-full font-bold text-xl shadow-lg transition transform hover:-translate-y-1 flex items-center justify-center">
              Home Services
            </Link>
          </div>

        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="p-6 border rounded-lg hover:shadow-lg transition bg-blue-50">
              <Activity className="text-blue-600 w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Modern Technology</h3>
              <p className="text-gray-600">State-of-the-art diagnostic laboratory and medical equipment.</p>
            </div>
            <div className="p-6 border rounded-lg hover:shadow-lg transition bg-blue-50">
              <Users className="text-blue-600 w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Qualified Doctors</h3>
              <p className="text-gray-600">Highly qualified team of specialists and consultants.</p>
            </div>
            <div className="p-6 border rounded-lg hover:shadow-lg transition bg-blue-50">
              <Clock className="text-blue-600 w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">24/7 Service</h3>
              <p className="text-gray-600">Round-the-clock emergency and hospital services.</p>
            </div>
            <div className="p-6 border rounded-lg hover:shadow-lg transition bg-blue-50">
              <ShieldCheck className="text-blue-600 w-12 h-12 mb-4" />
              <h3 className="text-xl font-bold mb-2">Affordable Care</h3>
              <p className="text-gray-600">Quality healthcare services at affordable rates for the community.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Need Home Medical Services?</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            We offer home sampling and home nursing services in G-13 and G-14 sectors. 
            Get quality care in the comfort of your home.
          </p>
          <Link to="/home-services" className="inline-flex items-center text-blue-700 font-bold hover:underline text-lg">
            Learn More <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

// Helper Component for Banner Services
const ServiceRow: React.FC<{ icon: React.ElementType, title: string, subtitle?: string }> = ({ icon: Icon, title, subtitle }) => (
  <div className="flex items-center space-x-4 p-2 rounded hover:bg-blue-100/50 transition">
    <div className="flex-shrink-0 bg-blue-600 p-2 rounded-lg text-white">
      <Icon size={20} />
    </div>
    <div className="leading-tight">
      <h4 className="font-bold text-gray-800">{title}</h4>
      {subtitle && <span className="text-sm text-red-600 font-semibold">{subtitle}</span>}
    </div>
  </div>
);

export default Home;