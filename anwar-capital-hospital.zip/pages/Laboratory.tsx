import React, { useState, useMemo } from 'react';
import { LabTest, LabBooking } from '../types';
import { Search, Info, Beaker, Filter, Calendar, User, Phone, CheckCircle, ShoppingCart, Plus, Trash2, FileText, X, Printer, Download, MapPin } from 'lucide-react';

interface Props {
  tests: LabTest[];
  onBook: (booking: Omit<LabBooking, 'id' | 'status'>) => void;
}

const CATEGORIES = [
  { label: 'All Tests', value: 'all' },
  { label: 'Blood / Hematology', value: 'blood' },
  { label: 'Urine Analysis', value: 'urine' },
  { label: 'Stool / Gastro', value: 'stool' },
  { label: 'Viral / PCR', value: 'pcr' },
  { label: 'Hormonal', value: 'hormone' },
  { label: 'Radiology', value: 'radiology' }
];

const Laboratory: React.FC<Props> = ({ tests, onBook }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [cart, setCart] = useState<LabTest[]>([]);
  const [isSlipOpen, setIsSlipOpen] = useState(false);
  const [formData, setFormData] = useState({ patientName: '', contact: '', date: '' });
  
  // Receipt State
  const [showReceipt, setShowReceipt] = useState(false);
  const [receiptData, setReceiptData] = useState<LabBooking | null>(null);

  const filteredTests = useMemo(() => {
    return tests.filter(test => {
      const name = test.name.toLowerCase();
      const term = searchTerm.toLowerCase();
      
      // Text Search
      const matchesSearch = name.includes(term);

      // Category Filter
      let matchesCategory = true;
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'blood') {
          matchesCategory = name.includes('blood') || name.includes('cbc') || name.includes('serum') || name.includes('lipid') || name.includes('lft') || name.includes('cp') || name.includes('iron') || name.includes('ferritin');
        } else if (selectedCategory === 'urine') {
          matchesCategory = name.includes('urine');
        } else if (selectedCategory === 'stool') {
          matchesCategory = name.includes('stool') || name.includes('h. pylori');
        } else if (selectedCategory === 'pcr') {
          matchesCategory = name.includes('pcr') || name.includes('dengue') || name.includes('hcv') || name.includes('covid') || name.includes('hbsag') || name.includes('malaria') || name.includes('typhidot');
        } else if (selectedCategory === 'hormone') {
          matchesCategory = name.includes('tsh') || name.includes('t3') || name.includes('t4') || name.includes('fsh') || name.includes('lh') || name.includes('prolactin') || name.includes('cortisol');
        } else if (selectedCategory === 'radiology') {
          matchesCategory = name.includes('x-ray') || name.includes('ultrasound');
        }
      }

      return matchesSearch && matchesCategory;
    });
  }, [tests, searchTerm, selectedCategory]);

  const addToCart = (test: LabTest) => {
    if (!cart.find(t => t.id === test.id)) {
      setCart([...cart, test]);
    }
  };

  const removeFromCart = (testId: string) => {
    setCart(cart.filter(t => t.id !== testId));
  };

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length > 0) {
      const bookedTests = cart.map(t => ({
        id: t.id,
        name: t.name,
        originalRate: t.rate,
        price: Math.round(t.rate * 0.8)
      }));

      const totalAmount = bookedTests.reduce((sum, t) => sum + t.price, 0);

      const bookingDetails = {
        id: Math.floor(100000 + Math.random() * 900000).toString(),
        tests: bookedTests,
        totalAmount,
        patientName: formData.patientName,
        contact: formData.contact,
        date: formData.date,
        status: 'Pending' as const
      };

      onBook(bookingDetails);
      
      // Switch to Receipt View
      setReceiptData(bookingDetails);
      setShowReceipt(true);
      
      // Clear Cart
      setCart([]);
      setFormData({ patientName: '', contact: '', date: '' });
    }
  };

  const closeAll = () => {
    setIsSlipOpen(false);
    setShowReceipt(false);
    setReceiptData(null);
  };

  const handleDownloadPDF = () => {
    const element = document.getElementById('printable-receipt');
    if (element && (window as any).html2pdf) {
      const opt = {
        margin: 10,
        filename: `ACH-Lab-Receipt-${receiptData?.id || 'slip'}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };
      (window as any).html2pdf().set(opt).from(element).save();
    } else {
      alert("PDF generation is initializing, please try again in a moment.");
    }
  };

  // Calculations for current cart
  const totalActual = cart.reduce((sum, t) => sum + t.rate, 0);
  const totalDiscounted = cart.reduce((sum, t) => sum + Math.round(t.rate * 0.8), 0);
  const totalSavings = totalActual - totalDiscounted;

  return (
    <div className="py-12 bg-gray-50 relative">
      <div className="container mx-auto px-4 flex flex-col lg:flex-row gap-8 pb-20">
        
        {/* Sidebar Info */}
        <div className="lg:w-1/4 space-y-6">
          <div className="bg-gradient-to-b from-blue-900 to-blue-800 text-white p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-4">ACH Laboratory</h2>
            
            {/* Discount Banner */}
            <div className="bg-yellow-400 text-blue-900 p-4 rounded-lg shadow-md mb-6 animate-pulse">
              <div className="flex items-center justify-center space-x-2">
                <span className="text-3xl font-black">20%</span>
                <div className="flex flex-col leading-tight">
                  <span className="font-bold text-lg">FLAT DISCOUNT</span>
                  <span className="text-xs font-semibold">ON ALL TESTS</span>
                </div>
              </div>
            </div>

            <p className="mb-4 text-blue-100 text-sm">
              Select multiple tests to generate your discounted slip instantly.
            </p>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-sm uppercase text-gray-400">Filter by Category</h4>
              <div className="flex flex-col space-y-2">
                {CATEGORIES.map(cat => (
                  <button 
                    key={cat.value}
                    onClick={() => setSelectedCategory(cat.value)}
                    className={`text-left px-3 py-2 rounded text-sm transition ${selectedCategory === cat.value ? 'bg-blue-600 font-bold shadow' : 'hover:bg-blue-700'}`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Test List */}
        <div className="lg:w-3/4">
          <div className="bg-white p-6 rounded-lg shadow-sm border mb-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <h2 className="text-2xl font-bold text-gray-800 flex items-center">
                <Beaker className="mr-2 text-blue-600" /> Lab Tests
              </h2>
              <div className="relative w-full md:w-96">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input 
                  type="text" 
                  placeholder="Search test name or keyword..." 
                  className="w-full pl-10 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-gray-50"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="bg-white border rounded-lg overflow-hidden shadow-sm">
            <div className="max-h-[600px] overflow-y-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-100 sticky top-0 z-10">
                  <tr>
                    <th className="px-6 py-4 text-xs font-bold text-gray-600 uppercase tracking-wider">Test Name</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-600 uppercase tracking-wider text-right hidden sm:table-cell">Actual Price</th>
                    <th className="px-6 py-4 text-xs font-bold text-green-700 uppercase tracking-wider text-right">Discounted Price</th>
                    <th className="px-6 py-4 text-xs font-bold text-gray-600 uppercase tracking-wider text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredTests.length > 0 ? (
                    filteredTests.map(test => {
                      const isInCart = cart.some(t => t.id === test.id);
                      return (
                        <tr key={test.id} className="hover:bg-blue-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="font-semibold text-gray-800">{test.name}</div>
                            {test.instructions && (
                              <p className="text-xs text-blue-600 mt-1 flex items-start">
                                <Info size={12} className="mr-1 mt-0.5 flex-shrink-0" />
                                <span>{test.instructions}</span>
                              </p>
                            )}
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500 text-right hidden sm:table-cell decoration-dashed line-through">
                            Rs. {test.rate}
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span className="bg-green-100 text-green-800 py-1 px-3 rounded-full text-sm font-bold">
                              Rs. {Math.round(test.rate * 0.8)}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <button 
                              onClick={() => isInCart ? removeFromCart(test.id) : addToCart(test)}
                              className={`flex items-center justify-center w-full sm:w-auto px-4 py-2 rounded-md font-medium text-sm transition shadow-sm ${
                                isInCart 
                                  ? 'bg-green-600 text-white hover:bg-green-700'
                                  : 'bg-white border border-blue-600 text-blue-600 hover:bg-blue-50'
                              }`}
                            >
                              {isInCart ? (
                                <><CheckCircle className="w-4 h-4 mr-1" /> Added</>
                              ) : (
                                <><Plus className="w-4 h-4 mr-1" /> Add to Slip</>
                              )}
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={4} className="px-6 py-12 text-center text-gray-500">
                        <div className="flex flex-col items-center">
                          <Filter className="w-12 h-12 text-gray-300 mb-2" />
                          <p className="text-lg">No tests found</p>
                          <p className="text-sm">Try adjusting your search or category filter.</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            <div className="bg-gray-50 px-6 py-4 border-t text-sm text-gray-500 flex justify-between">
              <span>Showing {filteredTests.length} tests</span>
              <span>Total Tests: {tests.length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Cart Button */}
      {cart.length > 0 && !isSlipOpen && (
        <div className="fixed bottom-6 right-6 z-40">
          <button 
            onClick={() => setIsSlipOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 rounded-full shadow-2xl flex items-center space-x-3 transform transition hover:scale-105"
          >
            <div className="relative">
              <ShoppingCart className="w-6 h-6" />
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                {cart.length}
              </span>
            </div>
            <span className="font-bold text-lg">Generate Slip</span>
          </button>
        </div>
      )}

      {/* Main Modal (Slip Preview OR Receipt) */}
      {isSlipOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full flex flex-col my-8 max-h-[90vh]">
            
            {/* Modal Header - Hide on print */}
            <div className="bg-gray-800 text-white p-4 flex justify-between items-center no-print flex-shrink-0">
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5" />
                <h3 className="font-bold text-lg">{showReceipt ? 'Booking Confirmed' : 'Lab Booking Slip Preview'}</h3>
              </div>
              <button onClick={closeAll} className="hover:bg-gray-700 p-1 rounded transition">
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto bg-gray-50">
              
              {!showReceipt ? (
                /* --- FORM & PREVIEW MODE --- */
                <div className="p-6">
                  {/* Slip Header Info */}
                  <div className="text-center mb-6 border-b pb-4">
                    <h2 className="text-2xl font-bold text-blue-900 uppercase">Anwar Capital Hospital</h2>
                    <p className="text-gray-500 text-sm">Diagnostic Laboratory Services</p>
                    <div className="mt-2 inline-block bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded border border-green-200">
                      20% DISCOUNT APPLIED
                    </div>
                  </div>

                  {/* Items Table */}
                  <div className="bg-white rounded-lg shadow-sm border overflow-hidden mb-6">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100 text-gray-700">
                        <tr>
                          <th className="px-4 py-2 text-left">Test Name</th>
                          <th className="px-4 py-2 text-right">Rate</th>
                          <th className="px-4 py-2 text-right">Discount</th>
                          <th className="px-4 py-2 text-right">Net Price</th>
                          <th className="px-4 py-2 text-center w-10"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {cart.map((test, index) => (
                          <tr key={`${test.id}-${index}`}>
                            <td className="px-4 py-3">
                              <div className="font-medium text-gray-800">{test.name}</div>
                            </td>
                            <td className="px-4 py-3 text-right text-gray-500 line-through decoration-red-400">{test.rate}</td>
                            <td className="px-4 py-3 text-right text-green-600 font-medium">-{Math.round(test.rate * 0.2)}</td>
                            <td className="px-4 py-3 text-right font-bold text-gray-800">{Math.round(test.rate * 0.8)}</td>
                            <td className="px-4 py-3 text-center">
                              <button onClick={() => removeFromCart(test.id)} className="text-red-500 hover:text-red-700">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-gray-50 font-bold text-gray-900">
                        <tr>
                          <td className="px-4 py-3 text-right">TOTAL</td>
                          <td className="px-4 py-3 text-right line-through text-gray-400">{totalActual}</td>
                          <td className="px-4 py-3 text-right text-green-600">-{totalSavings}</td>
                          <td className="px-4 py-3 text-right text-lg text-blue-900">{totalDiscounted}</td>
                          <td></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  {/* Patient Details Form */}
                  <div className="bg-white p-6 rounded-lg shadow-sm border">
                    <h4 className="font-bold text-gray-800 mb-4 flex items-center">
                      <User className="w-4 h-4 mr-2" /> Patient Details
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Patient Name</label>
                        <input 
                          required
                          type="text" 
                          className="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                          placeholder="Enter Full Name"
                          value={formData.patientName}
                          onChange={e => setFormData({...formData, patientName: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Contact No</label>
                        <input 
                          required
                          type="tel" 
                          className="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                          placeholder="0300-xxxxxxx"
                          value={formData.contact}
                          onChange={e => setFormData({...formData, contact: e.target.value})}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Visit Date</label>
                        <input 
                          required
                          type="date" 
                          className="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                          value={formData.date}
                          onChange={e => setFormData({...formData, date: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* --- FINAL RECEIPT VIEW --- */
                <div id="printable-receipt" className="p-8 bg-white min-h-[600px] flex flex-col">
                  {/* Receipt Header */}
                  <div className="flex justify-between items-start mb-8 border-b-2 border-gray-800 pb-4">
                     <div>
                       <div className="flex items-center space-x-3 mb-2">
                         <div className="w-10 h-10 bg-blue-900 rounded-full flex items-center justify-center text-white font-black text-xl">+</div>
                         <div>
                            <h1 className="text-2xl font-bold text-blue-900 leading-none">ACH</h1>
                            <h2 className="text-sm font-bold text-gray-800">Anwar Capital Hospital</h2>
                         </div>
                       </div>
                       <a href="https://share.google/OhGQdAUtBVmioh79r" target="_blank" rel="noopener noreferrer" className="text-xs text-gray-600 hover:text-blue-600 flex items-center">
                          <MapPin size={12} className="mr-1"/> Street 108, Sector G-13/1, Islamabad
                       </a>
                       <p className="text-xs text-gray-600 mt-1 pl-4">051-2306708</p>
                     </div>
                     <div className="text-right">
                       <div className="text-xl font-bold text-gray-400 uppercase tracking-widest">Lab Receipt</div>
                       <p className="text-sm text-gray-600 mt-1">Date: {new Date().toLocaleDateString()}</p>
                       <p className="text-sm font-bold">Ref #: {receiptData?.id}</p>
                     </div>
                  </div>

                  {/* Patient Info */}
                  <div className="grid grid-cols-2 gap-4 mb-8 bg-gray-50 p-4 rounded border">
                     <div>
                       <span className="text-gray-500 text-xs uppercase font-bold block mb-1">Patient Name</span>
                       <p className="font-bold text-lg text-gray-900">{receiptData?.patientName}</p>
                     </div>
                     <div className="text-right">
                       <span className="text-gray-500 text-xs uppercase font-bold block mb-1">Contact</span>
                       <p className="font-bold text-lg text-gray-900">{receiptData?.contact}</p>
                     </div>
                  </div>

                  {/* Receipt Table */}
                  <table className="w-full mb-8 text-sm">
                     <thead>
                       <tr className="border-b-2 border-gray-800 text-gray-600">
                         <th className="text-left py-2">Test Description</th>
                         <th className="text-right py-2">Rate</th>
                         <th className="text-right py-2">Discount</th>
                         <th className="text-right py-2">Net Amount</th>
                       </tr>
                     </thead>
                     <tbody className="text-gray-700">
                       {receiptData?.tests.map((t, idx) => (
                         <tr key={idx} className="border-b border-gray-100">
                           <td className="py-2 font-medium">{t.name}</td>
                           <td className="text-right py-2">{t.originalRate}</td>
                           <td className="text-right py-2 text-green-600">-{t.originalRate - t.price}</td>
                           <td className="text-right py-2 font-bold text-black">{t.price}</td>
                         </tr>
                       ))}
                     </tbody>
                  </table>

                  {/* Totals */}
                  <div className="flex justify-end mb-12">
                    <div className="w-1/2 md:w-1/3 space-y-2 text-sm">
                      <div className="flex justify-between text-gray-600">
                        <span>Subtotal:</span>
                        <span>{receiptData?.tests.reduce((acc, t) => acc + t.originalRate, 0)}</span>
                      </div>
                      <div className="flex justify-between text-green-600 font-medium">
                        <span>Total Savings:</span>
                        <span>-{receiptData && (receiptData.tests.reduce((acc, t) => acc + t.originalRate, 0) - receiptData.totalAmount)}</span>
                      </div>
                      <div className="flex justify-between text-xl font-bold text-blue-900 border-t-2 border-gray-800 pt-2 mt-2">
                        <span>Total Payable:</span>
                        <span>Rs. {receiptData?.totalAmount}</span>
                      </div>
                    </div>
                  </div>

                  {/* Instructions */}
                  <div className="bg-yellow-50 border border-yellow-200 p-3 rounded mb-8 text-xs text-yellow-800">
                     <strong>Instructions:</strong>
                     <ul className="list-disc ml-4 mt-1 space-y-1">
                        <li>Please bring this receipt for sample collection.</li>
                        <li>Fasting 10-12 hours is required for Lipid Profile & Fasting Sugar.</li>
                        <li>Report collection time will be mentioned on the sample collection slip.</li>
                     </ul>
                  </div>

                  {/* Footer */}
                  <div className="text-center text-xs text-gray-400 mt-auto pt-8 border-t">
                    <p>This is a computer generated slip and does not require a signature.</p>
                    <p className="mt-1">Thank you for choosing Anwar Capital Hospital.</p>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="p-4 bg-white border-t flex justify-between items-center no-print flex-shrink-0">
               {!showReceipt ? (
                 <>
                  <button 
                    onClick={() => setIsSlipOpen(false)}
                    className="text-gray-600 font-medium hover:text-gray-900 px-4"
                  >
                    + Add More Tests
                  </button>
                  <button 
                    onClick={handleBookSubmit}
                    disabled={!formData.patientName || !formData.contact || !formData.date}
                    className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white px-8 py-3 rounded-md font-bold shadow-lg transition transform hover:scale-105 flex items-center"
                  >
                    Confirm Booking
                  </button>
                 </>
               ) : (
                 <>
                   <button 
                    onClick={closeAll}
                    className="text-gray-600 font-medium hover:text-gray-900 px-4"
                   >
                     Close
                   </button>
                   <div className="flex space-x-3">
                     <button 
                      onClick={handleDownloadPDF}
                      className="bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-md font-bold shadow-lg flex items-center"
                     >
                       <Download className="w-4 h-4 mr-2" /> Save PDF
                     </button>
                     <button 
                      onClick={() => window.print()}
                      className="bg-gray-800 hover:bg-gray-900 text-white px-6 py-3 rounded-md font-bold shadow-lg flex items-center"
                     >
                       <Printer className="w-4 h-4 mr-2" /> Print Slip
                     </button>
                     <button 
                      onClick={closeAll}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-md font-bold shadow-lg flex items-center"
                     >
                       <CheckCircle className="w-4 h-4 mr-2" /> Done
                     </button>
                   </div>
                 </>
               )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
};

export default Laboratory;