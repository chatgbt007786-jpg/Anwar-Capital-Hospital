import React from 'react';

const About: React.FC = () => {
  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white p-8 md:p-12 rounded-lg shadow-sm">
          <h1 className="text-3xl font-bold text-gray-800 mb-8 border-b pb-4">About Anwar Capital Hospital</h1>
          
          <div className="prose lg:prose-xl text-gray-700 leading-relaxed space-y-6">
            <p>
              Anwar Capital Hospital (ACH) is a modern, patient-centered healthcare facility dedicated 
              to providing safe, reliable, and affordable medical services to the community.
            </p>
            <p>
              Located in the heart of G-13/1 Islamabad, ACH combines advanced technology with a 
              compassionate team of doctors, nurses, and healthcare professionals.
            </p>
            <p className="font-medium text-blue-800 text-lg">
              We strive to make your healing journey safe, comfortable, and seamless.
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-blue-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2 text-blue-900">Our Mission</h3>
              <p className="text-sm">To provide accessible, high-quality healthcare that prioritizes patient well-being and community health.</p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg">
              <h3 className="font-bold text-lg mb-2 text-blue-900">Our Vision</h3>
              <p className="text-sm">To be the leading healthcare provider in the region, known for excellence, integrity, and compassion.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;