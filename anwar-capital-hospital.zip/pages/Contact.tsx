import React from 'react';
import { Phone, MapPin, Mail, Clock, Star } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-bold text-center mb-12 text-gray-800">Contact Us</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Info */}
          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Hospital Address</h3>
                <p className="text-gray-600">Street 108, Sector G-13/1,<br/>Islamabad, Pakistan</p>
                <a 
                  href="https://share.google/OhGQdAUtBVmioh79r" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center mt-2 text-blue-600 font-bold hover:underline"
                >
                  <MapPin size={16} className="mr-1" /> Get Directions
                </a>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                <Star className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Reviews</h3>
                <p className="text-gray-600">We value your feedback.</p>
                <a 
                  href="https://share.google/OhGQdAUtBVmioh79r" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center mt-2 text-yellow-600 font-bold hover:underline"
                >
                  <Star size={16} className="mr-1 fill-current" /> Rate us on Google
                </a>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Phone Numbers</h3>
                <p className="text-gray-600">051-2301708</p>
                <p className="text-gray-600">0333-5613108</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Email Address</h3>
                <p className="text-gray-600">info@ach.com.pk</p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">Working Hours</h3>
                <p className="text-gray-600">Hospital: 24/7</p>
                <p className="text-red-600 font-semibold">Emergency: 24/7</p>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="bg-gray-50 p-8 rounded-lg shadow-sm border">
            <h3 className="text-xl font-bold mb-6">Send us a Message</h3>
            <form onSubmit={(e) => { e.preventDefault(); alert("Message sent!"); }} className="space-y-4">
              <input type="text" placeholder="Your Name" className="w-full p-3 border rounded focus:outline-none focus:border-blue-500" required />
              <input type="email" placeholder="Your Email" className="w-full p-3 border rounded focus:outline-none focus:border-blue-500" required />
              <textarea placeholder="Message" rows={4} className="w-full p-3 border rounded focus:outline-none focus:border-blue-500" required></textarea>
              <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 transition">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;