import React, { useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { Doctor, Department, LabTest, Appointment, HomeServiceRequest } from '../types';
import { LayoutDashboard, Users, TestTubes, Calendar, Siren, LogOut, CheckCircle, Search, Save, X } from 'lucide-react';

interface AdminProps {
  doctors: Doctor[];
  setDoctors: React.Dispatch<React.SetStateAction<Doctor[]>>;
  departments: Department[];
  setDepartments: React.Dispatch<React.SetStateAction<Department[]>>;
  labTests: LabTest[];
  setLabTests: React.Dispatch<React.SetStateAction<LabTest[]>>;
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  homeRequests: HomeServiceRequest[];
  setHomeRequests: React.Dispatch<React.SetStateAction<HomeServiceRequest[]>>;
  emergencyEnabled: boolean;
  setEmergencyEnabled: React.Dispatch<React.SetStateAction<boolean>>;
}

const AdminDashboard: React.FC<AdminProps> = (props) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');

  if (!isAuthenticated) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-sm">
          <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Admin Login</h2>
          <form onSubmit={(e) => {
            e.preventDefault();
            if (password === 'ach108') setIsAuthenticated(true);
            else alert('Invalid Password');
          }}>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">Password</label>
              <input 
                type="password" 
                className="w-full p-3 border rounded focus:outline-none focus:border-blue-500"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter password"
              />
            </div>
            <button type="submit" className="w-full bg-blue-800 text-white font-bold py-3 rounded hover:bg-blue-900">
              Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-blue-900 text-white flex-shrink-0 flex flex-col">
        <div className="p-6 border-b border-blue-800">
          <h1 className="text-xl font-bold">ACH Admin</h1>
        </div>
        <nav className="p-4 space-y-2 flex-1">
          <TabButton to="/admin" label="Dashboard" icon={<LayoutDashboard size={20} />} exact />
          <TabButton to="/admin/doctors" label="Doctors" icon={<Users size={20} />} />
          <TabButton to="/admin/lab" label="Lab Tests" icon={<TestTubes size={20} />} />
          <TabButton to="/admin/appointments" label="Appointments" icon={<Calendar size={20} />} />
        </nav>
        <div className="p-4 border-t border-blue-800">
          <button 
            onClick={() => setIsAuthenticated(false)}
            className="flex items-center space-x-3 w-full p-3 rounded hover:bg-red-600 transition text-left"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        <Routes>
          <Route path="" element={<DashboardOverview {...props} />} />
          <Route path="doctors" element={<DoctorsManager {...props} />} />
          <Route path="lab" element={<LabManager {...props} />} />
          <Route path="appointments" element={<AppointmentsManager {...props} />} />
        </Routes>
      </div>
    </div>
  );
};

// Helper Components for Admin

const TabButton = ({ to, label, icon, exact = false }: { to: string; label: string; icon: React.ReactNode, exact?: boolean }) => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Check if active. If exact is true, match exact path, otherwise startsWith
  const isActive = exact 
    ? location.pathname === to 
    : location.pathname.startsWith(to);

  return (
    <button 
      onClick={() => navigate(to)}
      className={`flex items-center space-x-3 w-full p-3 rounded transition text-left ${
        isActive ? 'bg-blue-700 text-white shadow-md' : 'hover:bg-blue-800 text-blue-100'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
};

const DashboardOverview: React.FC<AdminProps> = ({ appointments, homeRequests, emergencyEnabled, setEmergencyEnabled }) => {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Dashboard Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-blue-500">
          <h3 className="text-gray-500 text-sm font-bold uppercase">Pending Appointments</h3>
          <p className="text-3xl font-bold text-gray-800 mt-2">{appointments.filter(a => a.status === 'Pending').length}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-green-500">
          <h3 className="text-gray-500 text-sm font-bold uppercase">Pending Home Requests</h3>
          <p className="text-3xl font-bold text-gray-800 mt-2">{homeRequests.filter(r => r.status === 'Pending').length}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border-l-4 border-red-500 flex justify-between items-center">
          <div>
            <h3 className="text-gray-500 text-sm font-bold uppercase">Emergency Status</h3>
            <p className="text-xl font-bold text-gray-800 mt-2">{emergencyEnabled ? 'ACTIVE (24/7)' : 'Standard Hours'}</p>
          </div>
          <button 
            onClick={() => setEmergencyEnabled(!emergencyEnabled)}
            className={`px-4 py-2 rounded font-bold text-white transition ${emergencyEnabled ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-400 hover:bg-gray-500'}`}
          >
            <Siren />
          </button>
        </div>
      </div>
    </div>
  );
};

const DoctorsManager: React.FC<AdminProps> = ({ doctors, setDoctors }) => {
  const [newDoc, setNewDoc] = useState<Partial<Doctor>>({});
  
  const addDoctor = () => {
    if(newDoc.name && newDoc.department) {
      setDoctors([...doctors, { ...newDoc, id: Date.now().toString() } as Doctor]);
      setNewDoc({});
      alert("Doctor added successfully!");
    } else {
      alert("Please fill in at least Name and Department.");
    }
  };

  const removeDoctor = (id: string) => {
    if(window.confirm("Are you sure you want to remove this doctor?")) {
      setDoctors(doctors.filter(d => d.id !== id));
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Manage Doctors</h2>
      
      <div className="bg-white p-6 rounded-lg shadow-sm mb-6 border">
        <h3 className="font-bold mb-4 text-lg border-b pb-2">Add New Doctor</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
          <input className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Name (e.g. Dr. Ali)" value={newDoc.name || ''} onChange={e => setNewDoc({...newDoc, name: e.target.value})} />
          <input className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Department" value={newDoc.department || ''} onChange={e => setNewDoc({...newDoc, department: e.target.value})} />
          <input className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Qualification" value={newDoc.qualification || ''} onChange={e => setNewDoc({...newDoc, qualification: e.target.value})} />
          <input className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" placeholder="Specialization" value={newDoc.specialization || ''} onChange={e => setNewDoc({...newDoc, specialization: e.target.value})} />
          <input className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none" placeholder="OPD Time" value={newDoc.opdTime || ''} onChange={e => setNewDoc({...newDoc, opdTime: e.target.value})} />
        </div>
        <button onClick={addDoctor} className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 font-bold">Add Doctor</button>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden border">
        <table className="w-full text-left">
          <thead className="bg-gray-50 text-gray-700 font-bold uppercase text-xs">
            <tr>
              <th className="p-4">Name</th>
              <th className="p-4">Department</th>
              <th className="p-4">Qualification</th>
              <th className="p-4">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {doctors.map(d => (
              <tr key={d.id} className="hover:bg-gray-50">
                <td className="p-4 font-medium">{d.name}</td>
                <td className="p-4">{d.department}</td>
                <td className="p-4 text-sm text-gray-600">{d.qualification}</td>
                <td className="p-4">
                  <button onClick={() => removeDoctor(d.id)} className="text-red-600 hover:text-red-800 text-sm font-bold bg-red-50 px-3 py-1 rounded">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const LabManager: React.FC<AdminProps> = ({ labTests, setLabTests }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [priceUpdate, setPriceUpdate] = useState<{id: string, rate: string}>({id: '', rate: ''});

  const updatePrice = (id: string) => {
    const rate = parseInt(priceUpdate.rate);
    if (!isNaN(rate)) {
      setLabTests(labTests.map(t => t.id === id ? { ...t, rate } : t));
      setPriceUpdate({id: '', rate: ''});
    }
  };

  const filteredTests = labTests.filter(t => 
    t.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Manage Lab Tests</h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search test..." 
            className="pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none w-64"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden border">
        <div className="max-h-[600px] overflow-y-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-100 sticky top-0 z-10 shadow-sm">
              <tr>
                <th className="p-4 font-bold text-gray-700">Test Name</th>
                <th className="p-4 font-bold text-gray-700">Current Rate</th>
                <th className="p-4 font-bold text-gray-700">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filteredTests.length > 0 ? (
                filteredTests.map(t => (
                  <tr key={t.id} className="hover:bg-blue-50 transition">
                    <td className="p-4">{t.name}</td>
                    <td className="p-4 font-mono">{t.rate}</td>
                    <td className="p-4">
                      {priceUpdate.id === t.id ? (
                        <div className="flex items-center space-x-2">
                          <input 
                            type="number" 
                            className="w-24 border border-blue-300 rounded px-2 py-1 outline-none focus:border-blue-500"
                            value={priceUpdate.rate}
                            autoFocus
                            onChange={e => setPriceUpdate({...priceUpdate, rate: e.target.value})}
                          />
                          <button onClick={() => updatePrice(t.id)} className="bg-green-600 hover:bg-green-700 text-white p-1 rounded">
                            <Save size={16} />
                          </button>
                          <button onClick={() => setPriceUpdate({id: '', rate: ''})} className="bg-gray-400 hover:bg-gray-500 text-white p-1 rounded">
                            <X size={16} />
                          </button>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setPriceUpdate({id: t.id, rate: t.rate.toString()})} 
                          className="text-blue-600 hover:text-blue-800 text-sm font-bold border border-blue-200 hover:border-blue-400 px-3 py-1 rounded bg-white"
                        >
                          Edit Price
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="p-8 text-center text-gray-500">No tests found matching "{searchTerm}"</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <div className="text-right text-sm text-gray-500">
        Showing {filteredTests.length} of {labTests.length} tests
      </div>
    </div>
  );
};

const AppointmentsManager: React.FC<AdminProps> = ({ appointments, setAppointments }) => {
  const toggleStatus = (id: string) => {
    setAppointments(appointments.map(a => 
      a.id === id ? { ...a, status: a.status === 'Pending' ? 'Approved' : 'Completed' } : a
    ));
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">Appointments</h2>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden border">
        <table className="w-full text-left">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-4 font-bold text-gray-700">Patient</th>
              <th className="p-4 font-bold text-gray-700">Doctor</th>
              <th className="p-4 font-bold text-gray-700">Date</th>
              <th className="p-4 font-bold text-gray-700">Status</th>
              <th className="p-4 font-bold text-gray-700">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {appointments.length === 0 && <tr><td colSpan={5} className="p-8 text-center text-gray-500">No appointments yet.</td></tr>}
            {appointments.map(a => (
              <tr key={a.id} className="hover:bg-gray-50">
                <td className="p-4">
                  <div className="font-medium text-gray-900">{a.patientName}</div>
                  <div className="text-sm text-gray-500">{a.contact}</div>
                </td>
                <td className="p-4">{a.doctorName}</td>
                <td className="p-4 text-sm">{a.date}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                    a.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                    a.status === 'Approved' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                  }`}>
                    {a.status}
                  </span>
                </td>
                <td className="p-4">
                  {a.status !== 'Completed' && (
                    <button onClick={() => toggleStatus(a.id)} className="flex items-center text-blue-600 hover:text-blue-800 font-medium">
                      <CheckCircle size={16} className="mr-1" />
                      {a.status === 'Pending' ? 'Approve' : 'Complete'}
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminDashboard;